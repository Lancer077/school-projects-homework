import re
import sys


#declare the infile and set it up
infile = open(sys.argv[1], "read")
in_str = infile.read()

#declare the outfile and set it up
outfile = open(sys.argv[2], "w+")

#declare the list of numbers and their replacements
origList = ["10th", "10", "9th", "9", "8th", "8", "7th", "7", "6th", "6", "5th", "5", "4th", "4", "3rd", "3", "2nd", "2", "1st", "1", "0"]
subList = ["tenth", "ten", "ninth", "nine", "eighth", "eight", "seventh", "seven", "sixth", "six", "fifth", "five", "fourth", "four", "third", "three", "second", "two", "first", "one", "zero"]

#split the input text file into separate lines
#this is useful for checking each word in order while maintaining knoweledge of the line it originally appeared on
lines = re.split("\n", in_str)

#iterate through each line in the input document
for i in range(len(lines)):
    words = re.split(" ", lines[i]) #split each word up from the input line
    for j in range(len(words)): #iterate throught each word
        for k in range(len(origList)): #iterate through the list of numbers that are getting replaced, this is only O(n^2) on the technicallity that the list above will never grow due to user input
            if(re.match(origList[k]+"\W.*", words[j]) or origList[k] == words[j]): #use regex to try and find a match
                words[j] = re.sub(origList[k], subList[k], words[j]) #if we find a match, substitute the replacement without messsing with any other part of the word such as punctuation
        if(j != 0): #formatting stuff
            outfile.write(" " + words[j]) #write the replacements to the outfile
        else: #formatting stuff
            outfile.write(words[j]) #write teh replacements to the outfile
    if(i < len(lines)-1): #formatting stuff
        outfile.write("\n") #new line to retain the original formatting
