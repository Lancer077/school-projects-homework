import re
import sys

#function to check customer's ID
def checkCustID(s, rec):
    if(re.match(r"^[A-Z]{2}\d{4}$", s)): #if we get a match
        pass #then we do nothing
    else: #if we do not get a match
        outfile.write("Error in Customer ID field of record " + str(rec) + ": " + s + "\n") #we output an error message

#function to check customer name
def checkName(s, rec):
    if(re.match(r"(^[a-zA-Z][a-zA-Z]+(\s([a-zA-Z])*)*([a-zA-Z]$|,\sJr\.$|,\sSr\.$|,\sI+$|,\sV+$|,\sI+V+$|\sV+I+$))", s)): #looking for a match
        pass #same as above
    else:
        outfile.write("Error in Name field of record " + str(rec) + ": "+ s + "\n") #output error message

#function to check purchase date
def checkPurchaseDate(s, rec): #accidentally misread the instructions as needing to accept mm/dd/yyyy and dd/mm/yy I was very happy when reread the assignment
    if(re.match(r"(((^0[1-9])|(^1[0-2]))\/((0[1-9])|([1-2][0-9])|(3[0-1]))\/((\d{4}$)|(\d{2}$)))", s)):
        pass
    else:
        outfile.write("Error in Purchase Date field of record " + str(rec) + ": " + s + "\n")

#function to check number of items purchased
def checkNumPurchased(s, rec):
    if(re.match(r"^\d+$", s) and not(re.match(r"0", s))): #there's probably a better way of doing this but I started this program today, it is also due today
        pass
    else:
        outfile.write("Error in Number Purchased field of record " + str(rec) + ": " + s + "\n")

#function to check total cost of items purchased
def checkPurchaseAmount(s, rec):
    if(re.match(r"^\$\d+\.\d{2}$", s)):
        pass
    else:
        outfile.write("Error in Purchase Amount field of record " + str(rec) + ": " + s + "\n")


#opens the input file
infile = open(sys.argv[1], "read")
in_str = infile.read()

#sets up the output file
outfile = open(sys.argv[2], "w+")

#splits up each line
lines = re.split("\n", in_str) #break up the input string into each individual entry

#iterates through each line
for i in range(len(lines)):
    if(lines[i] != ""): #the last line of the input file was empty so this case had to be handled
        fields = re.split(";", lines[i]) #break up each individual entry into their respective fields
        checkCustID(fields[0], i+1) #call each function with their respective element
        checkName(fields[1], i+1) #I add 1 to the line number because it starts at 0 so I don't have to add it later
        checkPurchaseDate(fields[2], i+1) #
        checkNumPurchased(fields[3], i+1) #
        checkPurchaseAmount(fields[4], i+1) #

















#spacing
